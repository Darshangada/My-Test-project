import React from 'react'

export const Home = () => {
  return (
    <div>
        <div className="home">
            <h1>Title</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                 Fuga quisquam ipsum alias beatae aperiam porro optio vel, laudantium velit in, natus amet a expedita, 
                 esse ex laboriosam est doloribus labore</p>
                 <button>View More</button>
        </div>
    </div>
  )
}
export default Home

