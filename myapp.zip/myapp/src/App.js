import logo from './logo.svg';
import './App.css';
import Navbar from './Componants/Navbar';
import Home from './Componants/Home';
import { Card } from './Componants/Card';

function App() {
  return (
    <>
    <Navbar></Navbar>
    <Home></Home>
    <Card></Card>
    </>
  );
}

export default App;
